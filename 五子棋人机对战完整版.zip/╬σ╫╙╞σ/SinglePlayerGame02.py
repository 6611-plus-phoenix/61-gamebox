from PyQt5 import QtGui, QtCore

from PyQt5.QtWidgets import *
from PyQt5.QtGui import * # QFont
from PyQt5.QtCore import *
from PyQt5 import *
import sys
import MyButton
import random
import test


class Chessman(QLabel):
    # color : black  white
    def __init__(self, color = 'black',parent = None):
        super().__init__(parent)
        self.color = color
        self.pic = None
        if self.color == 'black':
            self.pic = QPixmap('source/黑子.png')
        else:
            self.pic = QPixmap('source/白子.png') # PNG
        self.setPixmap(self.pic)
        self.setFixedSize(self.pic.size()) # 设置棋子大小
    def move1(self, a0: QtCore.QPoint):
        super().move(a0.x()-15, a0.y()-15)
    def move2(self, x,y):
        super().move(35+30*y, 35+30*x)

class SinglePlayGame(QWidget):

    backSignal = pyqtSignal() # 返回信号
    startSignal = pyqtSignal() # 开始信号
    regretSignal = pyqtSignal() # 悔棋信号
    admitSignal = pyqtSignal() # 认输信号

    def __init__(self, parent = None):
        super().__init__(parent=parent)

        # 左上角 chessboard[0][0]
        # 右上角 chessboard[0][18]
        # 左下角 chessboard[18][0]
        # 右下角 chessboard[18][18]
        # chessboard[行下标 y][列下表 x]
        self.chessboard = [ [None for i in range(20)] for i in range(20)]   #存放chessman位置
        self.history = []   #存放chessman

        self.is_over = False

        # 落子棋子颜色
        self.turnChessColor = 'black'

        # 此时的棋子状态QLabel
        self.lb1 = QLabel(self)
        self.lb1.move(670,490)
        self.lb1.setPixmap(QPixmap('source/黑手.png'))
        # 设置背景图片
        p = QPalette(self.palette()) # 获得当前的调色板
        brush = QBrush(QImage('source/游戏界面.png'))
        p.setBrush(QPalette.Background, brush) # 设置调色板
        self.setPalette(p) # 给窗口设置调色板

        # 设置标题
        self.setWindowTitle('五子棋-人机对战')
        # 设置窗口图标
        self.setWindowIcon(QIcon('source/icon.ico'))
        # 设置窗口大小
        self.resize(QImage('source/游戏界面.png').size())

        self.backBtn = MyButton.MyButton('source/返回按钮_hover.png',
                                         'source/返回按钮_normal.png',
                                         'source/返回按钮_press.png',
                                         parent=self)
        self.backBtn.move(650, 50)
        #绑定返回按钮点击信号和槽函数
        self.backBtn.clicked.connect(self.goBack)

        self.startBtn = MyButton.MyButton('source/开始按钮_hover.png',
                                          'source/开始按钮_normal.png',
                                          'source/开始按钮_press.png',
                                          parent=self)
        self.startBtn.move(645, 250)
        self.startBtn.clicked.connect(self.start)

        self.regretBtn = MyButton.MyButton('source/悔棋按钮_hover.png',
                                           'source/悔棋按钮_normal.png',
                                           'source/悔棋按钮_press.png',
                                           parent=self)
        self.regretBtn.move(645, 330)
        self.regretBtn.clicked.connect(self.regret)


        self.admitBtn = MyButton.MyButton('source/认输按钮_hover.png',
                                          'source/认输按钮_normal.png',
                                          'source/认输按钮_press.png',
                                          parent=self)
        self.admitBtn.move(645, 410)
        self.admitBtn.clicked.connect(self.admit)


    def goBack(self):
        self.backSignal.emit() #发射返回信号
        self.close()

    def regret(self):
        try:
            if self.is_over == False:
                self.regretSignal.emit()
                m = self.history.pop()
                m.close()
                self.chessboard[m.x][m.y] = None
                m = self.history.pop()
                m.close()
                self.chessboard[m.x][m.y] = None
        except Exception as e:
            print(e)
    def start(self):
        self.startSignal.emit() # 发射开始信号

    def admit(self):
        self.admitSignal.emit() # 发射认输信号
        if self.is_over == False:
            if self.turnChessColor == 'black':
                QMessageBox.information(self, "信息", self.tr("白棋胜利!"))
                self.is_over = True
            else:
                QMessageBox.information(self, "信息", self.tr("黑棋胜利!"))
                self.is_over = True

# 随机白棋
    def algorithm(self):
        while True:
            a = random.randint(0, 18)
            b = random.randint(0, 18)
            if self.chessboard[a][b] == None:
                self.chessboard[a][b] = 'white'
                self.chessman2 = Chessman(color=self.chessboard[a][b], parent=self)
                self.chessman2.move2(a, b)
                self.chessman2.show()
                self.chessman2.x = a
                self.chessman2.y = b
                self.history.append(self.chessman2)
                # 显示棋子
                return

    #a0的参数类型是QtGui.QMouseEvent
    def mouseReleaseEvent(self, a0: QtGui.QMouseEvent):
        pos,chess_index = self.reversePos(a0.pos())
        if self.is_over == True:
            return
        if pos == None:
            return

        # 判断棋盘中当前位置有没有棋子
        if self.chessboard[chess_index[0]][chess_index[1]] != None:
            return

        self.chessman1 = Chessman(color=self.turnChessColor, parent=self)
        self.chessman1.move1(pos)
        self.chessman1.show() # 显示棋子
        self.chessman1.x = chess_index[0]
        self.chessman1.y = chess_index[1]
        self.history.append(self.chessman1)

        self.chessboard[chess_index[0]][chess_index[1]] = self.turnChessColor
        self.algorithm()
        # self.auto()
        self.showwin()




        # 将棋子存入列表


# 判断输赢
    def showwin(self):
        for i in range(0, 19):
            for j in range(0, 19):
                if self.chessboard[i][j] == 'black' and self.chessboard[i][j + 1] == 'black' and \
                                self.chessboard[i][j + 2] == 'black' and self.chessboard[i][j + 3] == 'black' and \
                                self.chessboard[i][j + 4] == 'black':
                    QMessageBox.information(self, "信息", self.tr("黑棋胜利!"))
                    self.is_over = True
                elif self.chessboard[i][j] == 'black' and self.chessboard[i + 1][j] == 'black' and \
                                self.chessboard[i + 2][j] == 'black' and self.chessboard[i + 3][j] == 'black' and \
                                self.chessboard[i + 4][j] == 'black':
                    QMessageBox.information(self, "信息", self.tr("黑棋胜利!"))
                    self.is_over = True
                elif self.chessboard[i][j] == 'black' and self.chessboard[i + 1][j - 1] == 'black' and \
                                self.chessboard[i + 2][j - 2] == 'black' and self.chessboard[i + 3][
                            j - 3] == 'black' and \
                                self.chessboard[i + 4][j - 4] == 'black':
                    QMessageBox.information(self, "信息", self.tr("黑棋胜利!"))
                    self.is_over = True
                elif self.chessboard[i][j] == 'black' and self.chessboard[i + 1][j + 1] == 'black' and \
                                self.chessboard[i + 2][j + 2] == 'black' and self.chessboard[i + 3][
                            j + 3] == 'black' and \
                                self.chessboard[i + 4][j + 4] == 'black':
                    QMessageBox.information(self, "信息", self.tr("黑棋胜利!"))
                    self.is_over = True
                elif self.chessboard[i][j] == 'white' and self.chessboard[i][j + 1] == 'white' and \
                                self.chessboard[i][j + 2] == 'white' and self.chessboard[i][j + 3] == 'white' and \
                                self.chessboard[i][j + 4] == 'white':
                    QMessageBox.information(self, "信息", self.tr("白棋胜利!"))
                    self.is_over = True
                elif self.chessboard[i][j] == 'white' and self.chessboard[i + 1][j] == 'white' and \
                                self.chessboard[i + 2][j] == 'white' and self.chessboard[i + 3][j] == 'white' and \
                                self.chessboard[i + 4][j] == 'white':
                    QMessageBox.information(self, "信息", self.tr("白棋胜利!"))
                    self.is_over = True
                elif self.chessboard[i][j] == 'white' and self.chessboard[i + 1][j - 1] == 'white' and \
                                self.chessboard[i + 2][j - 2] == 'white' and self.chessboard[i + 3][
                            j - 3] == 'white' and self.chessboard[i + 4][j - 4] == 'white':
                    QMessageBox.information(self, "信息", self.tr("白棋胜利!"))
                    self.is_over = True
                elif self.chessboard[i][j] == 'white' and self.chessboard[i + 1][j + 1] == 'white' and \
                                self.chessboard[i + 2][j + 2] == 'white' and self.chessboard[i + 3][
                            j + 3] == 'white' and self.chessboard[i + 4][j + 4] == 'white':
                    QMessageBox.information(self, "信息", self.tr("白棋胜利!"))
                    self.is_over = True


    # x -= sx y -= sy  x /= 30  y /= 30  x = int(x+0.5) y = int(y + 0.5)
    # x = sx + i * 30  y = sy + j * 30 x-= 15 y-= 15
    # 棋子坐标转换与判断
    # 如果返回None：表示棋子位置无效
    # 如果返回坐标：实际的坐标位置
    def reversePos(self,pos):
        pos_x = pos.x()
        pos_y = pos.y()
        # 判断点击位置是否在棋盘内部 如果不在返回NULL
        # 棋盘的左边界：x: 50-15 = 35
        # 棋盘的右边界：x: 50+  30(格宽)*18（格数）= 590 + 15
        # 棋盘的上边界：y: 50-15 = 35
        # 棋盘的下边界：y: 590 + 15
        if pos_x <= 35 or pos_x >= 605 or pos_y <=35 or pos_y>=605:
            return None

        self.block_x = (pos_x - 35)//30 # 前面的方格数量 数组下标
        self.block_y = (pos_y - 25)//30 # 上面方格的数量 数组下标

        x = 50 + 30 * self.block_x # 计算水平坐标
        y = 50 + 30 * self.block_y



        return QPoint(x,y), (self.block_y,self.block_x)
        # 棋子坐标转换
        # return pos

    # def auto(self, point, color):
    #     '''
    #     自动落子
    #     :return:
    #     '''
    #     # point = self.getPoint()
    #
    #     # 注意：x,y坐标对应
    #     chess_index = (point.y(), point.x())  # 棋子在棋盘中的下标
    #     pos = QPoint(50 + point.x() * 30, 50 + point.y() * 30)  # 棋子在棋盘中的坐标
    #
    #     self.chessman = Chessman(color=color, parent=self)
    #     self.chessman.setIndex(chess_index[1], chess_index[0])
    #     self.chessman.move(pos)
    #     self.chessman.show()  # 显示棋子
    #
    #     # 显示标识
    #     self.focusPoint.move(QPoint(pos.x() - 15, pos.y() - 15))
    #     self.focusPoint.show()
    #     self.focusPoint.raise_()
    #
    #     self.chessboard[chess_index[0]][chess_index[1]] = self.chessman
    #
    #     # 历史记录
    #     self.history.append((chess_index[0], chess_index[1], self.chessman.color))
    #
    #     # 改变落子颜色
    #     if self.turnChessColor == 'black':
    #         self.turnChessColor = 'white'
    #     else:
    #         self.turnChessColor = 'black'
    #     # 判断输赢
    #     result = self.isWin(self.chessman)
    #     if result != None:
    #         print(result + '赢了')
    #         self.showResult(result)
    #
    #     pass

if __name__ == '__main__':
    a = QApplication(sys.argv)
    m = SinglePlayGame()
    m.show()
    sys.exit(a.exec_())